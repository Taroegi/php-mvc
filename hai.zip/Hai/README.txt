Ini adalah virus jokes
Saya ingatkan lagi ini adalah virus jokes
jadi... jika sudah aktif,komputermu tidak akan kenapa napa,tetapi komputermu hanya merestart saja